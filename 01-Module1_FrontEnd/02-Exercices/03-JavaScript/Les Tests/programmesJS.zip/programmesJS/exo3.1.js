var nb = prompt("entrez un nombre");

if (nb > 0) {
    console.log("nombre positif");
} else {
    console.log("nombre négatif");
}