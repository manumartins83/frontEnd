var age = prompt("entrez l'âge");


if (age >= 6 && age <= 7) {
    console.log("poussin");
}

else if (age >= 8 && age <= 9) {
    console.log("pupille");
}
else if (age >= 10 && age <= 11) {
    console.log("minime");
}
else {
    console.log("cadet");
}